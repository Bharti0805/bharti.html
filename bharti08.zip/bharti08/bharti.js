// <!DOCTYPE html>
// <!-- saved from url=(0032)http://127.0.0.1:5500/index.html -->
// <html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
//     <meta name="viewport" content="width=device-width, initial-scale=1.0">
//     <title>Document</title>

//     <link rel="stylesheet" href="./kritika_files/kritika.js.download">
// </head>

// <body>
//     <script type="text/javascript">
//         document.write(76 + 90)
//         document.write("sum of 2 number")
//         document.write("87+ 98","<br>")

//         alert("enter your name")
//         prompt("enter your name??")
//         age = 35
//         document.write(age)
//         confirm("are you sure??")
//         prompt("enter your age??")
// confirm()


//     </script>166sum of 2 number87+ 98<br>35
// <script>

// hindi=50
// english=50
// maths=50
// if(hindi>50&&eng>60)
// {document.write("pass")}
// else{document.write("fail")}

// </script>fail
// <script>






// </script>





// // {/* <!-- Code injected by live-server -->
// <script>
// 	// <![CDATA[  <-- For SVG support
// 	if ('WebSocket' in window) {
// 		(function () {
// 			function refreshCSS() {
// 				var sheets = [].slice.call(document.getElementsByTagName("link"));
// 				var head = document.getElementsByTagName("head")[0];
// 				for (var i = 0; i < sheets.length; ++i) {
// 					var elem = sheets[i];
// 					var parent = elem.parentElement || head;
// 					parent.removeChild(elem);
// 					var rel = elem.rel;
// 					if (elem.href && typeof rel != "string" || rel.length == 0 || rel.toLowerCase() == "stylesheet") {
// 						var url = elem.href.replace(/(&|\?)_cacheOverride=\d+/, '');
// 						elem.href = url + (url.indexOf('?') >= 0 ? '&' : '?') + '_cacheOverride=' + (new Date().valueOf());
// 					}
// 					parent.appendChild(elem);
// 				}
// 			}
// 			var protocol = window.location.protocol === 'http:' ? 'ws://' : 'wss://';
// 			var address = protocol + window.location.host + window.location.pathname + '/ws';
// 			var socket = new WebSocket(address);
// 			socket.onmessage = function (msg) {
// 				if (msg.data == 'reload') window.location.reload();
// 				else if (msg.data == 'refreshcss') refreshCSS();
// 			};
// 			if (sessionStorage && !sessionStorage.getItem('IsThisFirstTime_Log_From_LiveServer')) {
// 				console.log('Live reload enabled.');
// 				sessionStorage.setItem('IsThisFirstTime_Log_From_LiveServer', true);
// 			}
// 		})();
// 	}
// 	else {
// 		console.error('Upgrade your browser. This Browser is NOT supported WebSocket for Live-Reloading.');
// 	}
// 	// ]]>
// </script>
// switch(7){
//     case 1:
//     document.write("monday")
//     break
//     case 2:
//     document.write("tuesday")
//     break
//     case 3:
//     document.write("wedensday")
//     break
//     case 4:
//     document.write("thusday")
//     break
//     case 5:
//     document.write("friday")
//     break
//     case 6:
//     document.write("saturday")
//     break
//     case 7:
//     document.write("sunday")
//     break

//     default:
//     document.write("in valide number")
//     break  
// }



// fruits=apple
// prompt("enter your value")
// frutis=prompt("enter your fruits")
// switch(kiwi){
//     case" orange":
//         document.write("orange")
//         break;
//     case "mango":
//        document.write("yellow")
//        break;
//    case banana:
//         document.write("yellow")
//        break;
//     case lichi:
//          document.write("red")
//       break;
//    case "kiwi":
//         document.write("green")
//       break;       
//  case apple:
//        document.write("red")
//      break  ;
//  default:
//        Document.write  ("invalied fruit")                                                        
// }
// // fn
// Number
// prompt=("enter your value")
// Number=prompt("enter your Number")
// for(Number=1;Number;++1){
//     document.write(table)
// }
// for(i=1;i<=10;++i){
//     Document.write( "2","*",i,"=",2*i,"<br>")
// }
// 

function abc(){
    a=document.getElementById('n1').value 
    document.write(a)
}



